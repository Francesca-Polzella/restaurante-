const btnGuardarcliente= document.querySelector('#guardar-cliente')
const contenido= document.querySelector('#resumen .contenido')

let cliente ={
    mesa:'',
    hora:'',
    pedido:[]
}

const categorias={
    1:'Pizzas',
    2:'Postres',
    3:'Jugos',
    4:'Cafe',
    5:'Combos',
    6:'Cortes'

}

btnGuardarcliente.addEventListener('click', guardarCliente)

function guardarCliente(){
    //console.log('hola')
    const mesa =document.querySelector('#mesa').value
    const hora=document.querySelector('#hora').value
    const camposVacios=[mesa,hora].some(i=>i=='')

    if(camposVacios){
        // todos los campos son vacios
        const existeAlerta= document.querySelector('.invalida')

        if(!existeAlerta){
            const alerta =document.createElement('div')
            alerta.textContent='Todos los campos son obligatorios'
            alerta.classList.add('invalida')
            document.querySelector('.modal-body form').appendChild(alerta)

            setTimeout(()=>{
                alerta.remove()
            },3000)
        }
    }else{
        // caso de que lo campos esten llenos
       // console.log('campos llenos')
       cliente={...cliente,mesa,hora}

       // ocualtar la ventana modal 
       var modalFormulario=document.querySelector('#formulario')
       var modal= bootstrap.Modal.getInstance(modalFormulario)
       modal.hide()
       mostrarsecciones()
       obtenermenu()
    }
}

function mostrarsecciones(){
    const secciones = document.querySelectorAll('.d-none')
    //console.log(secciones)
    secciones.forEach(secciones=>secciones.classList.remove('d-none'))
}

function obtenermenu(){
    const url = 'http://localhost:3000/menu'
    fetch(url)
    .then(respuesta=>respuesta.json())
    .then(res=> mostrarMenu(res))
    .catch(error=>console.log(error))
}

function mostrarMenu(menu){
   const contenido= document.querySelector('#menu .contenido')

   menu.forEach(menu=>{
        const fila= document.createElement('div')
        fila.classList.add('row', 'border-top')
        

        const nombre= document.createElement('div')
        nombre.classList.add('col-md-3', 'py-3')
        nombre.textContent= menu.nombre

       // console.log(nombre)
        
        const precio= document.createElement('div')
        precio.classList.add('col-md-3', 'py-3')
        precio.textContent= `$${menu.precio}`
        

        const categoria= document.createElement('div')
        categoria.classList.add('col-md-3', 'py-3')
        categoria.textContent= categorias[menu.categoria]

     
        const inputCantidad = document.createElement('input')
        inputCantidad.type='number'
        inputCantidad.min=0
        inputCantidad.value=0
        inputCantidad.id=`producto-${menu.id}`
        inputCantidad.classList.add('form-control')
        inputCantidad.onchange=function(){
            const cantidad = parseInt(inputCantidad.value)
            agregarOrden({...menu,cantidad})
            //console.log(cantidad)
        }


        const agregar= document.createElement('div')
        agregar.classList.add('col-md-3', 'py-3')


        agregar.appendChild(inputCantidad)
        fila.appendChild(precio)
        fila.appendChild(nombre)
        fila.appendChild(agregar)
        fila.appendChild(categoria)

       // console.log(fila)

        contenido.appendChild(fila)

        
    }) 
}

function agregarOrden(producto){
    let {pedido}= cliente
    //console.log(pedido)
    if(producto.cantidad>0){
        console.log('producto',producto.id)
        //console.log(pedido[1])
        if(pedido.some(i=>i===producto.id)){
            const pedidoActualizado=pedido.map(i=>{
                if(i.id===producto.id){
                    i.cantidad=producto.cantidad
                }else{
                    return i
                }
            })
            cliente.pedido=[...pedidoActualizado]

        }else{
            //console.log('pedido no existe ')
            cliente.pedido=[...pedido,producto]
            console.log(cliente.pedido)
        }
    
    }else{
        //cantidad es igual a 0
            const res = pedido.filter(i=>
                i.id !==producto.id
            )
            cliente.pedido=res
            cliente.pedido={...pedido,producto}
    }

    
 limpiarHTML()    
   if(cliente.pedido.length){
        actualizarResumen()

    }else{
        mensajePedidoVacio()
    }
}

function limpiarHTML(){
    while(contenido.firstChild){
        contenido.removeChild(contenido.firstChild)
    }
}

function mostrarsecciones(){
    const secciones =document.querySelectorAll('.d-none')
    //console.log(secciones)
    secciones.forEach(i=>i.classList.remove('d-none'))
}

function mensajePedidoVacio(){
    const texto= document.createElement('p')
    texto.textContent= 'Agrega productos al pedido'
    texto.classList.add('text-center')

    contenido.appendChild(texto)
}

function actualizarResumen(){
     
    const contenido= document.querySelector('#resumen .contenido')
    const resumen= document.createElement('div')
    resumen.classList.add('col-md-6','card','py-5','px-3','shadow')


    //mostrar mesa
    const mesa = document.createElement('p')
    mesa.textContent=`Mesa: ${cliente.mesa} `
    mesa.classList.add('fw-blod')

    //mostrar hora 
    const hora = document.createElement('p')
    hora.textContent=`Hora: ${cliente.hora} `
    hora.classList.add('fw-blod')

    const heading= document.createElement('p')
    heading.textContent=`Pedidos `
    heading.classList.add('fw-blod')

    //extraer el objeto cliente
    const {pedido}=cliente
    const grupo= document.createElement('ul')
    grupo.classList.add('list-group')
    pedido.forEach(i=>{
        const{nombre,precio,cantidad,id}= i
        const lista = document.createElement('li')
        lista.classList.add('list-group-item')

        const nombreP= document.createElement('p')
        nombreP.textContent=`Nombre:${nombre}`
        nombreP.classList.add('text-center','my-4')
    
        const precioP= document.createElement('p')
        precioP.textContent=`Precio:${precio}`
        precioP.classList.add('fw-bold')

        const cantidadP= document.createElement('p')
        cantidadP.textContent=`Cantidad:${cantidad}`
        cantidadP.classList.add('fw-bold')

        //estos son los lables

        const cantidadValor= document.createElement('p')
        cantidadValor.classList.add('fw-normal')
        cantidadValor.textContent= cantidad

        const precioValor= document.createElement('p')
        precioValor.classList.add('fw-normal')
        precioValor.textContent=`$${precio}`

        const subtotalP= document. createElement('p')
        subtotalP.classList.add('fw-bold')
        subtotalP.textContent='Subtotal: '

        const subtotalValor= document.createElement('p')
        subtotalValor.classList.add('fw-normal')
        subtotalValor.textContent= calcularSubtotal(i)
     //boton para eliminar pedido
     const btnEliminar = document.createElement('button')
     btnEliminar.classList.add('btn','btn-danger')
     btnEliminar.textContent = 'Eliminar pedido'
     //btnEliminar.onclick= vaciarPedido => esto funciono

    //  //agegar el evento para eliminar el pedido
     btnEliminar.onclick =function(){
        eliminarProducto(id)
     }


     //primer grupo de appendChild echo en clase 
        lista.appendChild(nombreP)
        lista.appendChild(precioP)
        lista.appendChild(cantidadP)
        lista.appendChild(btnEliminar)
        lista.appendChild(subtotalP)


        //segundo grupo de appendChild estos son labels
        cantidadP.appendChild(cantidadValor)
        precioP.appendChild(precioValor)
        subtotalP.appendChild(subtotalValor)

        grupo.appendChild(lista) 

    })


    
   
    resumen.appendChild(mesa)
    resumen.appendChild(hora)
    resumen.appendChild(heading)
    resumen.appendChild(grupo)

    // agregamos el contenido
    contenido.appendChild(resumen)


   // arreglar a donde va esta funcion 
   formularioPropina()
}

   
      
 
// function vaciarPedido() {
//     while(contenido.firstChild){
//         contenido.removeChild(contenido.firstChild) 
//       }
// }=> esto funciono 
  
function eliminarProducto(id){
    const{pedido}=cliente
    cliente.pedido= pedido.filter(item=>item.id !==id)
    limpiarHTML()

    if(cliente.pedido.length){
        actualizarResumen()
    }else{
        mensajePedidoVacio()
    }

    //ahora eliminar el producto debemos actualizarla cantidad a cero

    console.log(id)
    const productoeliminado=`#producto-${id}`
    const inputEliminado=document.querySelector(productoeliminado)
    inputEliminado.value=0

}


function calcularSubtotal(item){
    const{cantidad,precio}=item
    return`$${cantidad*precio}`
}

function formularioPropina(){
    const contenido= document.querySelector('#menu .contenido')
    const formulario= document.createElement('div')
    formulario.classList.add('col-md-6','formulario')

    const heading= document.createElement('h3')
    heading.classList.add('my-4')
    heading.textContent='Propina: '
    
    //propina al 5%
    const radio5 =document.createElement('input')
    radio5.type= 'radio'
    radio5.name='propina'
    radio5.value='5'
    radio5.classList.add('from-check-input')

    // crear el evento
    const radio5labels= document.createElement('label')
    radio5labels.textContent= '5%'
    radio5labels.classList.add('from-check-label')
    radio5.onclick= calcularPropina

    const radio5Div= document.createElement('div')
    radio5Div.classList.add('from-check')



    //propina al 10%
    const radio10 =document.createElement('input')
    radio10.type= 'radio'
    radio10.name='propina'
    radio10.value='10'
    radio10.classList.add('from-check-input')
    radio10.onclick= calcularPropina

    // crear el evento
    const radio10labels= document.createElement('label')
    radio10labels.textContent= '10%'
    radio10labels.classList.add('from-check-label')
    

    const radio10Div= document.createElement('div')
    radio10Div.classList.add('from-check')


    
    //propina al 25%
    const radio25 =document.createElement('input')
    radio25.type= 'radio'
    radio25.name='propina'
    radio25.value='25'
    radio25.classList.add('from-check-input')
    radio25.onclick= calcularPropina

    // crear el evento
    const radio25labels= document.createElement('label')
    radio25labels.textContent= '25%'
    radio25labels.classList.add('from-check-label')
    

    const radio25Div= document.createElement('div')
    radio25Div.classList.add('from-check')



    //appendChild de la propina al 5%
    radio5Div.appendChild(radio5)
    radio5Div.appendChild(radio5labels)
    
    formulario.appendChild(radio5Div)
   


    // appendChild de la propina al 10%
    radio10Div.appendChild(radio10)
    radio10Div.appendChild(radio10labels)
    
    formulario.appendChild(radio10Div)
    

    //appendChild de la propina al 25%

    radio25Div.appendChild(radio25)
    radio25Div.appendChild(radio25labels)
    
    formulario.appendChild(radio25Div)
    


    contenido.appendChild(formulario)
}


function calcularPropina(){

    console.log('calcular propina')
    const radioSeleccionado = document.querySelector('[name="propina"]:checked').value;
    console.log(radioSeleccionado);

    const {pedido} = cliente;
    //console.log(pedido);

    let subtotal = 0;
    pedido.forEach(item=>{
        subtotal += item.cantidad * item.precio;
        console.log()
    });

    const divTotales = document.createElement('div');
    divTotales.classList.add('total-pagar');

    //propina
    const propina = ((subtotal *parseInt(radioSeleccionado))/100);
    const total = propina + subtotal;
    //console.log(total)

    //subtotal
    const subtotalParrafo = document.createElement('p');
    subtotalParrafo.classList.add('fs-3','fw-bold','mt-5');
    subtotalParrafo.textContent = 'Subtotal Consumo: ';

    const subtotalP = document.createElement('span');
    subtotalP.classList.add('fs-normal');
    subtotalP.textContent = `$${subtotal}`;
    subtotalParrafo.appendChild(subtotalP);

    const propinaParrafo = document.createElement('span');
    propinaParrafo.classList.add('fw-normal');
    propinaParrafo.textContent = 'Propina: ';

    const propinaP = document.createElement('span');
    propinaP.classList.add('fw-normal');
    propinaP.textContent = `$${propina}`;
    
    propinaParrafo.appendChild(propinaP);

    //total
    const totalParrafo = document.createElement('p');
    totalParrafo.classList.add('fs-3','fw-bold');
    totalParrafo.textContent = 'Total a Pagar: ';

    const totalp = document.createElement('p');
    totalp.classList.add('fs-normal');
    totalp.textContent = `$${total}`;

    totalParrafo.appendChild(totalp);

    const totalPagarDiv = document.querySelector('.total-pagar');
    if(totalPagarDiv){
        totalPagarDiv.remove();
    }

    divTotales.appendChild(subtotalParrafo);
    divTotales.appendChild(propinaParrafo);
    divTotales.appendChild(totalParrafo);

    const formulario = document.querySelector('.formulario');
    formulario.appendChild(divTotales);

 }